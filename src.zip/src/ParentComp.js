import React, { useState, useEffect } from "react";
import ChildComp from "./ChildComp";

function ParentComp() {
  const [data, setData] = useState([]);

  const getdata = (rcvdata) => {
    setData([...data, rcvdata]);
  };

  useEffect(() => {
    document.title = `${data.length} name`;
  });

  return (
    <div>
      <h3>This is new Parent Comp</h3>

      <h4>
        Name :
        {data.map((item, i) => {
          return <li key={i}>{item}</li>;
        })}
      </h4>
      <ChildComp getdata={getdata} />
    </div>
  );
}

export default ParentComp;
