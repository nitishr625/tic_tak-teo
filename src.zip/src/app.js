import React from "react";
import Parent from "./Parent";
import ParentComp from "./ParentComp";

export function App() {
  const divstyle = {
    backgroundColor: "red",
  };

  const secDivStyle = {
    backgroundColor: "wheat",
    height: 200,
    textAlign: "center",
  };
  return (
    <div>
      <div style={divstyle}>
        <h1>App Component</h1>
        <div style={{ background: "green" }}>
          <Parent />
        </div>
      </div>
      <div style={secDivStyle}>
        <ParentComp />
      </div>
    </div>
  );
}

export default App;
