import React, { useState } from "react";

function ChildComp(props) {
  const [name, setName] = useState("");
  const changeHandler = (e) => {
    setName(e.target.value);
  };

  const submitHandler = (e) => {
    e.preventDefault();
    props.getdata(name);
    setName("");
  };
  return (
    <div>
      <h3>This is new Child Comp</h3>
      <form action="" onSubmit={submitHandler}>
        <input type="text" value={name} onChange={changeHandler} />
        <button tyle="submit">Submit</button>
      </form>
    </div>
  );
}

export default ChildComp;
